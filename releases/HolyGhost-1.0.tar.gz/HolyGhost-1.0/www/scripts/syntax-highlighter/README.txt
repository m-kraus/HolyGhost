Code Syntax Highlighter.
Version 1.5.1
Copyright (C) 2004-2007 Alex Gorbatchev.
http://www.dreamprojections.com/syntaxhighlighter/

---

http://code.google.com/p/syntaxhighlighter/
http://alexgorbatchev.com/SyntaxHighlighter/download/
